%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Projeto filtros FIR
%Kaline B.F Mesquita
%Ferramentas:M�TODO DAS JANELAS
%Descri��o: Neste c�digo s�o utilizado dois filtro FIR para a filtragem de
%           uma som. No som h� uma pessoa falando, uma sirene e um chiado.
%           O c�digo retira o som da sirene e do chiado. Deixando o som da
%           voz da pessoa aud�vel.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clc; clear all;

% Carregamento do sinal de �udio
[x,fs]=audioread('C:\Users\Alunos\Downloads\fala_sirene_tm0.wav');
nbits=16;
% Play na musica original 
%wavplay(x,fs);

% Capturando informa��es

% Ts - Per�odo de amostragem
% t -Intervalo de amostragem
% fa - fa percorre vetor de amostras dos sinal
% f - Vetor de frequ�ncias em Hz
% X - Espectro de frequ�ncia do sinal de �udio

Ts = 1/fs;                  
t = 0:Ts:1-Ts;             
fa=[0:1:length(x)-1];      
f=fa.*fs/(length(x)-1);     
X=abs(fft(x));   

% Apresenta��o de plots
subplot(2,1,1);
plot(fa,abs(x));
title('Sinal de Voz');
subplot(2,1,2);
plot(f(1:round(length(x)/2)),X(1:round(length(x)/2)));
title('Espectro do sinal');

% ------------------------- 1� se��o de filtragem ---------------
% Filtro rejeita-faixa.
% fc - Frequ�ncia a ser eliminada
% r - coeficiente vari�vel do raio 
% wc - Convers�o da frequ�ncia de corte
% b - Coeficientes do numerador do filtro
% a - Coeficientes do denominador do filtro
% [H1,W1] - Resposta em Frequ�ncia do Filtro Notch
% e - Filtrando o sinal
% E - Resposta em frequ�ncia do sinal filtrado
% [I,T] - Resposta ao impulso do filtro FIR
 
fc = 200;                    
r = 0.9926;                 
wc = (2*pi*fc)/fs;          
b = [1 -2*cos(wc) 1];       
a = [1 -2*r*cos(wc) r^2];   
[H1,W1] = freqz(b, a, 512);  
e = filter(b,a,x);          
E = abs(fft(e));             
[I,T] = impz(b*10000, a*10000);         

% Coeficientes do segundo filtro notch
disp('Coeficientes do filtro rejeita-faixa FIR');
disp(b);
disp(a);

% Apresentando de plots
figure;
subplot(2,1,1);
plot(f(1:round(length(x)/2)),X(1:round(length(x)/2)));
hold on
plot(W1*(fs/(2*pi)), abs(H1*12000), 'r');
title('Representa��o do filtro rejeita-faixa FIR');
subplot(2,1,2);
plot (f(1:round(length(e)/2)), E(1:round(length(e)/2)));
title('Resposta em frequ�ncia do sinal filtrado FIR');
figure;
plot(T,abs(I));
title('Resposta ao impulso do filtro FIR');

% ------------------------- 2� se��o de filtragem ---------------
% Filtro passa-baixa.
% [H1,W1] -  Resposta em Frequ�ncia
% y - Filtrando o sinal
% Y - Resposta em frequ�ncia do sinal filtrado
% [I1, T1] - Resposta ao impulso do filtro FIR

B=fir1(100,0.05, 'low');
A=1;
[H1,W1] = freqz(B, 1, 1024); 
y = filter(B,A,e);           
Y = abs(fft(y));              
[I1,T1] = impz(B, A);         
% Coeficientes do segundo filtro notch
disp('Coeficientes do filtro passa-baixa FIR');
disp(B);
disp(A);

% Apresentando de plots
figure;
subplot(2,1,1);
plot(f(1:round(length(e)/2)),E(1:round(length(e)/2)));
hold on
plot(W1*(fs/(2*pi)), abs(H1*12000), 'r');
title('Representa��o do filtro passa-baixa FIR');
subplot(2,1,2);
plot (f(1:round(length(y)/2)), Y(1:round(length(y)/2)));
title('Resposta em frequ�ncia do sinal filtrado FIR');
figure;
plot(T1,abs(I1));
title('Resposta ao impulso do filtro FIR');

% Salvando sinal filtrado
audiowrite('C:\Users\Alunos\Downloads\fala_sirene_tmFIR.wav',y,fs);

% Play no voz filtrado
%[x1,fs1,nbits1]=wavread('C:\Users\usuario\Desktop\TRABALHOS\FILTRO-DIGITAIS\Codigos\Sons\fala_sirene_tmFIR.wav');
%am=(1)*x1;              % Amplifica��o do sinal.
%wavplay(am,fs1);

disp('100%!');
