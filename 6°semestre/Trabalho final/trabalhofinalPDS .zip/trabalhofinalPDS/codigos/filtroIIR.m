%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Projeto filtros IIR
%kaline B.F Mequita
%Ferramentas: FILTRO DE BUTTERWORTH E NOTCH.
%Descri��o: Neste c�digo s�o utilizado dois filtro IIR para a filtragem de
%           uma som. No som h� uma pessoa falando, uma sirene e um chiado.
%           O c�digo retira o som da sirene e do chiado. Deixando o som da
%           voz da pessoa aud�vel.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clc; clear all;
% Carregamento do sinal de audio
[x,fs]=audioread('C:\Users\Alunos\Downloads\fala_sirene_tm0.wav');
nbits=16;
% Play na musica original 
%wavplay(x,fs);


%1� parte:
%Ts - per�odo de amostragem
%t - intervalo de amostragem
%fa - percorre um vetor de amostras do sinal.
%f - vetor em frequ�ncia em Hz
%X - espectro de frequ�ncia do sinal de �udio

% Capturando informa��es
Ts = 1/fs;                  
t = 0:Ts:1-Ts;             
fa=[0:1:length(x)-1];      
f=fa.*fs/(length(x)-1);     
X=abs(fft(x));              

% Apresentando de plots
subplot(2,1,1);
plot(fa,abs(x));
title('Sinal de Voz');
subplot(2,1,2);
plot(f(1:(round(length(x)/2))),X(1:(round(length(x)/2))));
title('Espectro do sinal');


% ------------------------ 1� se��o de filtragem ---------------
% 1� Filtro notch

%Wo e BW - Par�metros de entrada
%[b,a] - Filtro Notch
%[H1, W1] - resposta em frequ�ncia do filtro
%Y - Resposta em frequ�ncia do sinal filtrado

Wo = 0.0275; BW=0.01;          
[b,a] = iirnotch(Wo,BW);       
[H1, W1]= freqz(b, a, 512);    
y = filter(b,a,x);             
Y = abs(fft(y));              

% Coeficientes do primeiro filtro notch
disp('Coeficientes do primeiro filtro notch');
disp(b);
disp(a);

% 2� Filtro notch

%Wo e BW - Par�metros de entrada
%[b1,a1] - Filtro Notch
%[H1, W1] - Resposta em frequ�ncia do filtro
%e - filtrando o sinal
%E - resposta em frequ�ncia do sinal filtrado
%[G, U] - Resposta ao impulso do filtro IIR
Wo = 0.018; BW=0.01;         
[b1,a1] = iirnotch(Wo,BW);     
[H1, W1]= freqz(b1, a1, 512); 
e = filter(b1,a1,y);           
E = abs(fft(e));               
[G,U] = impz(b1, a1);          

% Coeficientes do segundo filtro notch
disp('Coeficientes do segundo filtro notch');
disp(b1);
disp(a1);

% Apresenta��o de plots
figure;
subplot(2,1,1);
plot(f(1:(round(length(x)/2))),X(1:(round(length(x)/2))));
hold on;
plot(W1*(fs/(2*pi)), abs(H1*12000), 'r');
title('Representa��o do filtro notch IIR');
subplot(2,1,2);
plot (f(1:round(length(e)/2)), E(1:round(length(e)/2)));
title('Resposta em frequ�ncia do sinal filtrado IIR');
figure;
plot(U,abs(G));
title('Resposta ao impulso do filtro IIR');

% -------------------------- 2� se��o de filtragem ---------------

% Filtro de passa-baixa de butterworth

%[b1, a2] -  Par�metros de entrada
%[H1 , W1] - Resposta em frequ�ncia do filtro
%s - Filtrando o sinal
%S- Filtrando o sinal
%[T, T] Resposta ao impulso do filtro IIR
[b2, a2] = butter(10, 0.045, 'low');
[H1, W1]= freqz(b2, a2, 512);      
s = filter(b2,a2,e);               
S = abs(fft(s));                   
[I,T] = impz(b2, a2);               

% Coeficientes do filtro de butterworth
disp('Coeficientes do filtro de butterworth');
disp(b2);
disp(a2);

% apresentando de plots
figure;
subplot(2,1,1);
plot(f(1:(round(length(e)/2))),E(1:(round(length(e)/2))));
hold on;
plot(W1*(fs/(2*pi)), abs(H1*12000), 'r');
title('Representa��o do filtro butterworth (passa-baixa) IIR');
subplot(2,1,2);
plot (f(1:round(length(s)/2)), S(1:round(length(s)/2)) );
title('Resposta em frequ�ncia do sinal filtrado IIR');
figure;
plot(T,abs(I));
title('Resposta ao impulso do filtro IIR');

% Salvando sinal filtrado
audiowrite('C:\Users\Alunos\Downloads\fala_sirene_tmIIR.wav',s,fs);

% Play na voz filtrada
 % am - Amplifica��o do sinal.
[x1,fs1,nbits1]=wavread('C:\Users\Alunos\Downloads\fala_sirene_tmIIR.wav');
am=(1)*x1;             
wavplay(am,fs1);

disp('100%!');
